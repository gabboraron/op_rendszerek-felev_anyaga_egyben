//beadando1 Operacios rendszerek
//AWXYHE
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>
#include <string.h>
#include <time.h>

#define MAX_STRING_LEN 80
#define PHONE_NUMBER 15

struct order {
    time_t	 systime;
    char	 name[MAX_STRING_LEN];
    char	 email[MAX_STRING_LEN];
    int		 phonenumber;
    int		 size;    
};


//functions
void readName(struct order *current);
void checkValues(struct order *current);
void readEmail(struct order *current);
void readPhone(struct order *current);
void readSize(struct order *current);
void saveToFiles(struct order *current);
void getNewOrder(struct order *current);
void dbList(struct order *current);
void deleteOrder(struct order *current);
void modificator(struct order *current);

//read name
void readName(struct order *current){
    printf("Az ügyfél neve: ");
    scanf("%80s[^\n]", &current->name);
   // scanf("%s",current->name);
}

//read email
void readEmail(struct order *current){
    printf("Az ügyfél e-mail címe: ");
    char tmp[80];
    scanf("%s[^\n]", &current->email);
}

//read phone number
void readPhone(struct order *current){
    printf("Az ügyfél telefonszáma: ");
    scanf("%15i[^\n]", &current->phonenumber);
}

//read size of order
void readSize(struct order *current){
    printf("A rendelés mérete: ");
    scanf("%i", &current->size);
}

//check the submited values
void checkValues(struct order *current){
    printf("\n *** \n");
    printf("Név: %s \n", current->name);
    printf("e-mail: %s \n", current->email);
    printf("tel: %d \n", current->phonenumber);
    printf("méret: %d \n", current->size);
    printf("idő: %ld \n", current->systime);
    printf(" *** \n \n");
}

//save into file
void saveToFiles(struct order *current){
    /*int f,g;
    f=open("db.txt",O_WRONLY|O_CREAT,S_IRUSR|S_IWUSR);
    if(f<0){
        perror("Error at opening the database!\n");
        exit(1);
    }else {
        printf("Fájl nyitása írásra...\n");
    }    
    if(write(f,current,sizeof(current))!=sizeof(current)){
        perror("Error at writing!\n");
        exit(1);
    }else{
        //fwrite(&current, sizeof(struct order), 1, f);
        printf("Sikeres írás\n");
    }
    close(f);    */
    
    FILE * file=fopen("db.txt", "a");
    if(file != NULL){
        fwrite(current, sizeof(struct order), 1, file);
//        fwrite("\n", sizeof("\n"), 1, file);
/*        fwrite(current->name, sizeof(current->name), 1, file); 
        //fprintf(file, current->name);
        fwrite(" ", sizeof(" "), 1, file);
        fwrite(current->email, sizeof(current->email), 1, file);
        fwrite(" ", sizeof(" "), 1, file);
        fwrite(current->phonenumber, sizeof(current->phonenumber), 1, file);
        fwrite(" ", sizeof(" "), 1, file);
        fwrite(current->size, sizeof(current->size), 1, file);
        fwrite(" ", sizeof(" "), 1, file);
        fwrite(current->systime, sizeof(current->systime), 1, file);
        fwrite("\n", sizeof("\n"), 1, file);
        */
        fclose(file);
        //** TEST **//
/*        
        struct order *obj=malloc(sizeof(struct order));
        FILE * f=fopen("db.txt", "rb");
        if(f != NULL){
            fread(obj, sizeof(struct order), 1, f);
            fclose(f);
        }
        printf("%s/%s/%d/%d\n", obj->name, obj->email, obj->phonenumber, obj->size);
*/
/*
        FILE *f=fopen("db.txt","r");
        char buff[200];
        fscanf(f, "%s", buff);
        printf("\n *** \n1: %s\n *** \n", buff);
        fscanf(f, "%s", buff);
        printf("\n *** \n2: %s\n *** \n", buff);
        fclose(f);
*/
        //** *** **// 
    }
}

//read new values
void getNewOrder(struct order *current){
//   struct order tmp = &current;
   //read values  
   readName(current);
   readEmail(current); 
   readPhone(current);
   readSize(current);
   current->systime = time(NULL);
//   readName(&tmp);
//   readEmail(&tmp); 
//   readPhone(&tmp);
//   readSize(&tmp);
//   tmp.systime = time(NULL);
   // ** //
   checkValues(current);

   
   printf("Ezek megfelelőek? (i/n) ");
   char answer;
   char yes = 'i';
   scanf(" %c", &answer);
   
   if(answer == yes){ 
      printf("Mentés...\n");
      saveToFiles(current); //save to file
      printf("Mentve\n \n");
   } else {
      printf("Add meg újra! \n");
      getNewOrder(current);	
   }
}

//list the db
void dbList(struct order *current){
    int option;
    printf("|- Kilistázás: \n    1 - teljes lista\n    2 - szűrés ügyfélre\n    3 - szűrés teljesítmény ígényre\n    0 - kilép");
    scanf(" %i", &option);
    if(option == 0){
        exit(1);
    }
    if(option == 1){    
        struct order *obj=malloc(sizeof(struct order));
        FILE * file = fopen("db.txt","rb");
        fseek(file, 0, SEEK_SET);
        //while(!feof(file)){
        while(fread(obj, sizeof(struct order), 1, file)){
//        char buffer[300];
//        while(fread(buffer, sizeof buffer, 1, stream == 1){
//printf("LOG: op1\n");
//            fread(obj, sizeof(struct order), 1, file);
            printf("%s/%s/%d/%d\n", obj->name, obj->email, obj->phonenumber, obj->size);
        }
        if(feof(file)){printf("\n--END--\n");}
        else{printf("Some error...");} 
        
        /*char buffer[300];
        FILE * file = fopen("db.txt", "rb");
        while(fscanf(file,"%300s",bufer) == 1){
            printf("%s",buffer);
        }*/
    }
    if(option == 2){
       printf("ügyfél neve: ");
       char name[80];
       scanf(" %s",name);
       struct order *obj=malloc(sizeof(struct order));
       FILE * file = fopen("db.txt", "rb");
       fseek(file, 0, SEEK_SET);
       while(fread(obj,sizeof(struct order), 1, file)){
           if(strcmp(obj->name, name) == 0){
               printf("%s/%s/%d/%d\n", obj->name, obj->email, obj->phonenumber, obj->size);
           }
       }
       if(feof(file)){printf("\n--END--\n");}else{printf("ERROR");}
       fclose(file);
    }
    if(option == 3){
       printf("teljesítmény ígény: ");
       char size[80];
       scanf(" %s",size);
       struct order *obj=malloc(sizeof(struct order));
       FILE * file = fopen("db.txt", "rb");
       fseek(file, 0, SEEK_SET);
       while(fread(obj,sizeof(struct order), 1, file)){
            char tmp[sizeof(obj->size)];
            sprintf(tmp, "%d", obj->size);
            if(strcmp(tmp, size) == 0){
                printf("%s/%s/%d/%d\n", obj->name, obj->email, obj->phonenumber, obj->size);
            }
       }
       if(feof(file)){printf("\n--END--\n");}else{printf("ERROR");}
       fclose(file);
    }
}

//get the size of the db
int getDbSize(){
    int size = 0;
    struct order*obj=malloc(sizeof(struct order));
    FILE * file = fopen("db.txt", "rb");
    fseek(file, 0, SEEK_SET);
    while(fread(obj,sizeof(struct order), 1, file)){
         ++size;
    }   
    fclose(file);
    return size;
}

//modification of db
void modificator(struct order *current){
    printf("Módosítani kívánt ügyfél e-mail címe: ");
    char mail[80];
    scanf(" %s",mail);
    //modification
    int size=getDbSize();
    struct order arr_order[size];
    struct order *obj=malloc(sizeof(struct order));
    FILE * file = fopen("db.txt", "rb");
    fseek(file, 0, SEEK_SET);
    int idx = 0;
    while(fread(obj, sizeof(struct order), 1, file)){
         if(strcmp(obj->email, mail) == 0){
 //printf("\n *** \n mail match: %s AND %s\n *** \n", obj->email, mail);           
            //change
           /* struct order tmp; //tmp struct for the changed values
            //tmp = malloc(sizeof(&tmp));
            getNewOrder(&tmp);
            strcpy(arr_order[idx].name, tmp.name);
            //arr_order[idx].name = tmp.name;
            strcpy(arr_order[idx].email, tmp.email);
            //arr_order[idx].email = tmp.email;
            arr_order[idx].phonenumber= tmp.phonenumber;
            arr_order[idx].systime = tmp.systime;
            */
         }else{
            //copy the rest
            strcpy(arr_order[idx].name, obj->name);
            //arr_order[idx].name = obj->name;
            strcpy(arr_order[idx].email, obj->email);
            //arr_order[idx].email = obj->email;
            arr_order[idx].phonenumber = obj->phonenumber;
            arr_order[idx].size = obj->size;
            arr_order[idx].systime = obj->systime; 
         ++idx;
         }
    }
    
 //printf("\n *** \n the size of the db: %i \n *** \n", idx);
    size=idx;   
    fclose(file);
    fseek(file, 0, SEEK_SET);
    FILE * newfile=fopen("db.txt", "w+");
    idx=0;
    if(newfile != NULL){
    	for(idx=0; idx<size; ++idx){
    	        //printf("id: %i", idx);
    	        //checkValues(&arr_order[idx]);
        	fwrite(&arr_order[idx], sizeof(struct order), 1, newfile);
	}
    }
    fclose(newfile);
    getNewOrder(current);
    printf("Módosítások mentve\n");
}

//delte an order
void deleteOrder(struct order *current){
    printf("Törölni kívánt ügyfél e-mail címe: ");
    char mail[80];
    scanf(" %s",mail);
    //deleteOrder
    int size=getDbSize();
    struct order arr_order[size];
    struct order *obj=malloc(sizeof(struct order));
    FILE * file = fopen("db.txt", "rb");
    fseek(file, 0, SEEK_SET);
    int idx = 0;
    while(fread(obj, sizeof(struct order), 1, file)){
         if(strcmp(obj->email, mail) == 0){
 //printf("\n *** \n mail match: %s AND %s\n *** \n", obj->email, mail);           
            //delete
            printf("Törölve. \n");
         }else{
            //copy the rest
            strcpy(arr_order[idx].name, obj->name);
            //arr_order[idx].name = obj->name;
            strcpy(arr_order[idx].email, obj->email);
            //arr_order[idx].email = obj->email;
            arr_order[idx].phonenumber = obj->phonenumber;
            arr_order[idx].size = obj->size;
            arr_order[idx].systime = obj->systime; 
            ++idx;
         }
    }
    
 //printf("\n *** \n the size of the db: %i \n *** \n", idx);
    size=idx;   
    fclose(file);
    
    FILE * newfile=fopen("db.txt", "w+");
    fseek(file,0, SEEK_SET);
    idx=0;
    if(newfile != NULL){
    	for(idx=0; idx<size; ++idx){
        	fwrite(&arr_order[idx], sizeof(struct order), 1, newfile);
        	//printf("id: %i", idx);
        	//checkValues(&arr_order[idx]);
	}
    }
    fclose(newfile);
    printf("Módosítások mentve\n");
} 

//***

int main(k)
{
    printf("Fenyes Nap Kft \n Jellemzően egy évre vonatkoztatva 1000KW/h energiát 1KW teljesítményt nyujtó 4 darab napelem panel \n \n");
    struct order current; 	//struct init
//    current = malloc(sizof(*current));

   int option = 1;
   while(option != 0){
        printf("~ FENYES NAP ~ \n 0 kilépés \n 1 új felvétele \n 2 kilistázás \n 3 ügyfél módosítás \n 4 ügyfél törlése \n \nválasztás: ");
   	scanf(" %i", &option);	
   	if(option == 1){getNewOrder(&current);}
        if(option == 2){dbList(&current);}
        if(option == 3){modificator(&current);}
        if(option == 4){deleteOrder(&current);}
        else{printf("\n Hibás parancs\n");}
   }    
    return 0;
}

